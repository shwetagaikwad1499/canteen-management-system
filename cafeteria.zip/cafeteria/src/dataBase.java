
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
public class dataBase {

    /**
     *
     */
    public Connection conn = null;
//    As you run the project this function get called
    public boolean dataBase() {
        
        try {
            // db parameters
            String url = "jdbc:sqlite:cafeteria.db";
            // create a connection to the database
            conn = DriverManager.getConnection(url);
            if(conn!=null){
            return true;
            }
            
            System.out.println("Connection to SQLite has been established.");
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return false;
    }
    //    As you run the project this function get called
    public void createTables() {
        
        // SQL statement for creating a new table
        String sql = "CREATE TABLE IF NOT EXISTS userinfo (\n"
                + "    id integer PRIMARY KEY,\n"
                + "    name text NOT NULL,\n"
                + "    password text NOT NULL,\n"
                + "    username varchar NOT NULL,\n"
                + "    phone text NOT NULL UNIQUE\n"
                + ");";
        
        String sql1 = "CREATE TABLE IF NOT EXISTS items (\n"
                + "    id integer PRIMARY KEY,\n"
                + "    name text NOT NULL,\n"
                + "    price varchar NOT NULL\n"
                + ");";
        
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(dataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            // create a new table
            boolean execute = stmt.execute(sql);
            stmt.execute(sql1);
           
        } catch (SQLException ex) {
            Logger.getLogger(dataBase.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
//    it gets vale from signup page
    public boolean insertUser(String name, String pwd,String username,String phno) {
        try {
            String sql = "INSERT INTO userinfo(name,password,username,phone) VALUES(?,?,?,?)";
            PreparedStatement pstmt; 
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, pwd);
            pstmt.setString(3, username);
            pstmt.setString(4, phno);
            if(pstmt.executeUpdate() == 1){
            return true;
            }
        }
        catch(SQLIntegrityConstraintViolationException e){
            duplicate(true);
        }
        catch (SQLException ex) {
            Logger.getLogger(dataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean duplicate(boolean data){
        if(data){
        return duplicate();
        }
        return false;
    }

    Boolean duplicate() {
        return true;//To change body of generated methods, choose Tools | Templates.
    }
//    this function called by login file
    public boolean checkUser(String username,String pwd){
        try {
            String sql = "SELECT * FROM userinfo WHERE username == ? and password == ?";
            
            PreparedStatement pstmt  = conn.prepareStatement(sql);
            
            // set the value
            pstmt.setString(1,username);
            pstmt.setString(2,pwd);
            
            //
            ResultSet rs  = pstmt.executeQuery();
            
            return rs.next();
            
        } catch (SQLException ex) {
            Logger.getLogger(dataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
//    this function called by dashboard file
    public boolean insertItem(String name,String price){
         try {
            String sql = "INSERT INTO items(name,price) VALUES(?,?)";
            PreparedStatement pstmt; 
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, price);
            if(pstmt.executeUpdate() == 1){
            return true;
            }
        }
         catch (SQLException ex) {
            Logger.getLogger(dataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
    return false;
    }
    
    public void connClose(){
        try {
            conn.close();
        } catch (SQLException ex) {
            Logger.getLogger(dataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
             
//    this function called by dashboard file
    public String[] selectItem(String id){
    String[] items = new String[2];
    
        try {
            String sql = "SELECT * FROM items WHERE id == ?";
            
            PreparedStatement pstmt  = conn.prepareStatement(sql);
            
            // set the value
            pstmt.setString(1,id);
            //
            ResultSet rs  = pstmt.executeQuery();
            
            // loop through the result set
            while (rs.next()) {
               items[0] = rs.getString("name");
               items[1] = rs.getString("price");
            }
            
            return items;
        } catch (SQLException ex) {
            Logger.getLogger(dataBase.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
       
    }
    
}
