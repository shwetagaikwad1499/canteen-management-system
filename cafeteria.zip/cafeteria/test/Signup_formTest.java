/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sudarshan
 */
public class Signup_formTest {
    
    public Signup_formTest() {
    }
    
   
    /**
     * Test of isValid method, of class Signup_form.
     */
    @Test
    public void testIsValid() {
        System.out.println("isValid");
        String s = "";
        boolean expResult = false;
        boolean result = Signup_form.isValid(s);
        if(result == expResult){
        assertEquals(expResult, result);
        }else{
         // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
        }
    }

    /**
     * Test of SignUp method, of class Signup_form.
     */
    @Test
    public void testSignUp() {
        System.out.println("SignUp");
        String name = "hvjvj";
        String username = "dfsdf";
        String pwd = "sdfsf";
        String phno = "7885412791";
        Signup_form instance = new Signup_form();
        boolean expResult = true;
        boolean result = instance.SignUp(name, username, pwd, phno);
        if(result == expResult){
        assertEquals(expResult, result);
        }else{
         // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
        }
    }

   
    
}
