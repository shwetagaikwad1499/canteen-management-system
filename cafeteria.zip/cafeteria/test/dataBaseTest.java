/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sudarshan
 */
public class dataBaseTest {
    
   
    /**
     * Test of dataBase method, of class dataBase.
     */
    @Test
    public void testDataBase() {
        System.out.println("dataBase");
        dataBase instance = new dataBase();
        boolean expResult = true;
        boolean result = instance.dataBase();
        if(result == expResult){
        assertEquals(expResult, result);
        }else{
         // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
        }
    }

  

   

    /**
     * Test of duplicate method, of class dataBase.
     */
    @Test
    public void testDuplicate_boolean() {
        System.out.println("duplicate");
        boolean data = false;
        dataBase instance = new dataBase();
        boolean expResult = false;
        boolean result = instance.duplicate(data);
        if(result == expResult){
        assertEquals(expResult, result);
        }else{
         // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
        }
    }

    /**
     * Test of duplicate method, of class dataBase.
     */
    @Test
    public void testDuplicate_0args() {
        System.out.println("duplicate");
        dataBase instance = new dataBase();
        Boolean expResult = true;
        Boolean result = instance.duplicate();
       if(result == expResult){
        assertEquals(expResult, result);
        }else{
         // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
        }
    }
    
}
