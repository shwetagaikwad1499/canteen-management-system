/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sudarshan
 */
public class Login_formTest {
    
    public Login_formTest() {
    }
    
    
    /**
     * Test of checkUserTest method, of class Login_form.
     */
    @Test
    public void testCheckUserTest() {
        System.out.println("checkUserTest");
        String name = "ani";
        String pwd = "ani";
        Login_form instance = new Login_form();
        boolean expResult = true;
        boolean result = instance.checkUserTest(name, pwd);
        
        if(result == expResult){
        assertEquals(expResult, result);
        }else{
        fail("The test case is a prototype.");
        } 
    }

    /**
     * Test of main method, of class Login_form.
     */
   
}
